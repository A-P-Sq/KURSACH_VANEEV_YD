--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

-- Started on 2025-12-26 22:48:16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 4921 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 231 (class 1255 OID 25111)
-- Name: auth_user(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.auth_user(p_login character varying, p_password character varying) RETURNS TABLE(user_id integer, role_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT u.id, r.name
    FROM users u
    JOIN roles r ON u.role_id = r.id
    WHERE u.login = p_login AND u.password = p_password;
END;
$$;


ALTER FUNCTION public.auth_user(p_login character varying, p_password character varying) OWNER TO postgres;

--
-- TOC entry 230 (class 1255 OID 25019)
-- Name: check_car_not_sold(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_car_not_sold() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (SELECT is_sold FROM cars WHERE id = NEW.car_id) THEN
        RAISE EXCEPTION 'Автомобиль с ID % уже продан!', NEW.car_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_car_not_sold() OWNER TO postgres;

--
-- TOC entry 229 (class 1255 OID 25015)
-- Name: delete_car(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.delete_car(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM cars WHERE id = p_id AND is_sold = TRUE) THEN
        RAISE EXCEPTION 'Нельзя удалить проданный автомобиль!';
    END IF;
    DELETE FROM cars WHERE id = p_id;
END;
$$;


ALTER PROCEDURE public.delete_car(IN p_id integer) OWNER TO postgres;

--
-- TOC entry 227 (class 1255 OID 25011)
-- Name: get_cars_by_filters(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_cars_by_filters(p_brand character varying DEFAULT NULL::character varying, p_model character varying DEFAULT NULL::character varying, p_year integer DEFAULT NULL::integer) RETURNS TABLE(id integer, brand character varying, model character varying, year integer, price numeric, is_sold boolean)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.id, c.brand, c.model, c.year, c.price, c.is_sold
    FROM cars c
    WHERE (p_brand IS NULL OR c.brand ILIKE '%' || p_brand || '%')
      AND (p_model IS NULL OR c.model ILIKE '%' || p_model || '%')
      AND (p_year IS NULL OR c.year = p_year);
END;
$$;


ALTER FUNCTION public.get_cars_by_filters(p_brand character varying, p_model character varying, p_year integer) OWNER TO postgres;

--
-- TOC entry 250 (class 1255 OID 25130)
-- Name: get_sales_with_details(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_sales_with_details() RETURNS TABLE(sale_id integer, car_brand character varying, car_model character varying, client_fullname character varying, price_sold numeric, sale_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.id AS sale_id, 
        c.brand AS car_brand, 
        c.model AS car_model, 
        cl.fullname AS client_fullname, 
        s.price_sold, 
        s.sale_date
    FROM sales s
    JOIN cars c ON s.car_id = c.id
    JOIN clients cl ON s.client_id = cl.id
    ORDER BY s.sale_date DESC;
END;
$$;


ALTER FUNCTION public.get_sales_with_details() OWNER TO postgres;

--
-- TOC entry 228 (class 1255 OID 25013)
-- Name: insert_car(character varying, character varying, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_car(IN p_brand character varying, IN p_model character varying, IN p_year integer, IN p_price numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO cars (brand, model, year, price, is_sold)
    VALUES (p_brand, p_model, p_year, p_price, FALSE);
END;
$$;


ALTER PROCEDURE public.insert_car(IN p_brand character varying, IN p_model character varying, IN p_year integer, IN p_price numeric) OWNER TO postgres;

--
-- TOC entry 242 (class 1255 OID 25126)
-- Name: log_sale_delete(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_sale_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO sales_log (sale_id, log_date, action)
    VALUES (
        OLD.id, 
        CURRENT_TIMESTAMP, 
        'Продажа отменена. Автомобиль ID: ' || OLD.car_id || ', Клиент ID: ' || OLD.client_id
    );
    RETURN OLD;
END;
$$;


ALTER FUNCTION public.log_sale_delete() OWNER TO postgres;

--
-- TOC entry 241 (class 1255 OID 25125)
-- Name: log_sale_insert(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_sale_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO sales_log (sale_id, log_date, action)
    VALUES (
        NEW.id, 
        CURRENT_TIMESTAMP, 
        'Создана новая продажа. Автомобиль ID: ' || NEW.car_id || ', Клиент ID: ' || NEW.client_id
    );
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_sale_insert() OWNER TO postgres;

--
-- TOC entry 234 (class 1255 OID 25116)
-- Name: manage_client(text, character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.manage_client(IN p_oper text, IN p_fullname character varying, IN p_phone character varying, IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF p_oper = 'INSERT' THEN
        INSERT INTO public.clients (fullname, phone)
        VALUES (p_fullname, p_phone);
    ELSIF p_oper = 'DELETE' THEN
        DELETE FROM public.clients WHERE id = p_id;
    END IF;
END;
$$;


ALTER PROCEDURE public.manage_client(IN p_oper text, IN p_fullname character varying, IN p_phone character varying, IN p_id integer) OWNER TO postgres;

--
-- TOC entry 236 (class 1255 OID 25118)
-- Name: register_sale(integer, integer, numeric, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.register_sale(IN p_car_id integer, IN p_client_id integer, IN p_price_sold numeric, IN p_sale_date date DEFAULT CURRENT_DATE)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO sales (car_id, client_id, price_sold, sale_date)
    VALUES (p_car_id, p_client_id, p_price_sold, p_sale_date);

    UPDATE cars SET is_sold = TRUE WHERE id = p_car_id;
END;
$$;


ALTER PROCEDURE public.register_sale(IN p_car_id integer, IN p_client_id integer, IN p_price_sold numeric, IN p_sale_date date) OWNER TO postgres;

--
-- TOC entry 232 (class 1255 OID 25113)
-- Name: sync_car_sold_status(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sync_car_sold_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Обновляем статус машины на 'проданную' после вставки записи в sales
    UPDATE public.cars 
    SET is_sold = TRUE 
    WHERE id = NEW.car_id;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.sync_car_sold_status() OWNER TO postgres;

--
-- TOC entry 233 (class 1255 OID 25014)
-- Name: update_car(integer, character varying, character varying, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_car(IN p_id integer, IN p_brand character varying, IN p_model character varying, IN p_year integer, IN p_price numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE public.cars
    SET brand = p_brand,
        model = p_model,
        year = p_year,
        price = p_price
    WHERE id = p_id;
END;
$$;


ALTER PROCEDURE public.update_car(IN p_id integer, IN p_brand character varying, IN p_model character varying, IN p_year integer, IN p_price numeric) OWNER TO postgres;

--
-- TOC entry 235 (class 1255 OID 25115)
-- Name: update_client(integer, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_client(IN p_id integer, IN p_fullname character varying, IN p_phone character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE public.clients
    SET fullname = p_fullname,
        phone = p_phone
    WHERE id = p_id;
END;
$$;


ALTER PROCEDURE public.update_client(IN p_id integer, IN p_fullname character varying, IN p_phone character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 24969)
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    id integer NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    year integer,
    price numeric(10,2),
    is_sold boolean DEFAULT false,
    CONSTRAINT cars_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT cars_year_check CHECK (((year >= 1900) AND ((year)::numeric <= EXTRACT(year FROM CURRENT_DATE))))
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 24968)
-- Name: cars_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cars_id_seq OWNER TO postgres;

--
-- TOC entry 4922 (class 0 OID 0)
-- Dependencies: 221
-- Name: cars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cars_id_seq OWNED BY public.cars.id;


--
-- TOC entry 220 (class 1259 OID 24962)
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    fullname character varying(100) NOT NULL,
    phone character varying(20)
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 24961)
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO postgres;

--
-- TOC entry 4923 (class 0 OID 0)
-- Dependencies: 219
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- TOC entry 216 (class 1259 OID 24939)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 24938)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- TOC entry 4924 (class 0 OID 0)
-- Dependencies: 215
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 224 (class 1259 OID 24979)
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    car_id integer,
    client_id integer,
    sale_date date DEFAULT CURRENT_DATE NOT NULL,
    price_sold numeric(10,2),
    CONSTRAINT sales_price_sold_check CHECK ((price_sold > (0)::numeric))
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 24978)
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_id_seq OWNER TO postgres;

--
-- TOC entry 4925 (class 0 OID 0)
-- Dependencies: 223
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- TOC entry 226 (class 1259 OID 24997)
-- Name: sales_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_log (
    id integer NOT NULL,
    sale_id integer,
    log_date timestamp without time zone DEFAULT now(),
    action text NOT NULL
);


ALTER TABLE public.sales_log OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 24996)
-- Name: sales_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_log_id_seq OWNER TO postgres;

--
-- TOC entry 4926 (class 0 OID 0)
-- Dependencies: 225
-- Name: sales_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_log_id_seq OWNED BY public.sales_log.id;


--
-- TOC entry 218 (class 1259 OID 24948)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    role_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 24947)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 4927 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4729 (class 2604 OID 24972)
-- Name: cars id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars ALTER COLUMN id SET DEFAULT nextval('public.cars_id_seq'::regclass);


--
-- TOC entry 4728 (class 2604 OID 24965)
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- TOC entry 4726 (class 2604 OID 24942)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 4731 (class 2604 OID 24982)
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- TOC entry 4733 (class 2604 OID 25000)
-- Name: sales_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_log ALTER COLUMN id SET DEFAULT nextval('public.sales_log_id_seq'::regclass);


--
-- TOC entry 4727 (class 2604 OID 24951)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4911 (class 0 OID 24969)
-- Dependencies: 222
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (11, 'Toyota ', 'Carola ', 2020, 1231313.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (7, 'Toyota', 'Camry', 2021, 6000000.00, true);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (8, 'toyota', 'Land cruser 200', 2007, 2000.00, true);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (3, 'Audi', 'A4', 2021, 28000.00, true);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (19, 'Toyota', 'Corolla', 2020, 1800000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (20, 'Toyota', 'RAV4', 2021, 3200000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (21, 'Kia', 'Rio', 2020, 1200000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (22, 'Kia', 'Sportage', 2021, 2500000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (23, 'Kia', 'K5', 2022, 2900000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (24, 'Hyundai', 'Solaris', 2019, 1100000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (25, 'Lada', 'Vesta', 2023, 1500000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (26, 'BMW', 'X5', 2019, 5200000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (27, 'BMW', 'X5', 2021, 7500000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (28, 'BMW', 'X5', 2023, 9800000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (29, 'BMW', '3 Series', 2021, 4100000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (30, 'BMW', 'M5', 2022, 12000000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (31, 'Mercedes-Benz', 'E-Class', 2021, 5500000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (32, 'Mercedes-Benz', 'GLE', 2022, 8900000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (33, 'Mercedes-Benz', 'C-Class', 2020, 3800000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (34, 'Volkswagen', 'Polo', 2021, 1400000.00, false);
INSERT INTO public.cars (id, brand, model, year, price, is_sold) VALUES (35, 'Volkswagen', 'Tiguan', 2019, 2600000.00, false);


--
-- TOC entry 4909 (class 0 OID 24962)
-- Dependencies: 220
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.clients (id, fullname, phone) VALUES (1, 'Иван Иванов', '+79123456789');
INSERT INTO public.clients (id, fullname, phone) VALUES (2, 'Мария Петрова', '+79223456789123');
INSERT INTO public.clients (id, fullname, phone) VALUES (6, 'Иванов Иван Иванович', '89001112233');
INSERT INTO public.clients (id, fullname, phone) VALUES (7, 'Петров Петр Петрович', '89112223344');
INSERT INTO public.clients (id, fullname, phone) VALUES (8, 'Сидорова Анна Сергеевна', '89223334455');
INSERT INTO public.clients (id, fullname, phone) VALUES (9, 'Кузнецов Дмитрий Олегович', '89334445566');
INSERT INTO public.clients (id, fullname, phone) VALUES (10, 'Смирнова Елена Викторовна', '89445556677');


--
-- TOC entry 4905 (class 0 OID 24939)
-- Dependencies: 216
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.roles (id, name) VALUES (1, 'admin');
INSERT INTO public.roles (id, name) VALUES (2, 'manager');


--
-- TOC entry 4913 (class 0 OID 24979)
-- Dependencies: 224
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sales (id, car_id, client_id, sale_date, price_sold) VALUES (18, 7, 1, '2025-12-25', 6000000.00);
INSERT INTO public.sales (id, car_id, client_id, sale_date, price_sold) VALUES (19, 8, 1, '2025-12-25', 2000.00);
INSERT INTO public.sales (id, car_id, client_id, sale_date, price_sold) VALUES (22, 3, 2, '2025-12-26', 28000.00);


--
-- TOC entry 4915 (class 0 OID 24997)
-- Dependencies: 226
-- Data for Name: sales_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (18, 13, '2025-12-25 00:12:48.197316', 'Создана новая продажа. Автомобиль ID: 9, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (19, 13, '2025-12-25 00:13:44.454987', 'Продажа отменена. Автомобиль ID: 9, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (20, 12, '2025-12-25 00:13:45.883622', 'Продажа отменена. Автомобиль ID: 7, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (21, 1, '2025-12-25 00:13:47.968748', 'Продажа отменена. Автомобиль ID: 3, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (22, 14, '2025-12-25 00:13:52.514289', 'Создана новая продажа. Автомобиль ID: 8, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (23, 15, '2025-12-25 00:13:59.178716', 'Создана новая продажа. Автомобиль ID: 7, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (24, 16, '2025-12-25 00:14:02.806964', 'Создана новая продажа. Автомобиль ID: 9, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (25, 17, '2025-12-25 00:14:06.168384', 'Создана новая продажа. Автомобиль ID: 3, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (26, 14, '2025-12-25 00:14:16.715932', 'Продажа отменена. Автомобиль ID: 8, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (27, 15, '2025-12-25 00:14:18.964483', 'Продажа отменена. Автомобиль ID: 7, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (28, 17, '2025-12-25 00:14:20.623242', 'Продажа отменена. Автомобиль ID: 3, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (29, 16, '2025-12-25 00:14:21.959642', 'Продажа отменена. Автомобиль ID: 9, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (30, 18, '2025-12-25 02:15:22.4185', 'Создана новая продажа. Автомобиль ID: 7, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (31, 19, '2025-12-25 22:33:11.713267', 'Создана новая продажа. Автомобиль ID: 8, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (32, 20, '2025-12-25 23:12:43.355879', 'Создана новая продажа. Автомобиль ID: 9, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (33, 20, '2025-12-25 23:12:56.71598', 'Продажа отменена. Автомобиль ID: 9, Клиент ID: 2');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (34, 21, '2025-12-25 23:13:02.771966', 'Создана новая продажа. Автомобиль ID: 9, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (35, 21, '2025-12-25 23:13:07.303337', 'Продажа отменена. Автомобиль ID: 9, Клиент ID: 1');
INSERT INTO public.sales_log (id, sale_id, log_date, action) VALUES (36, 22, '2025-12-26 22:33:48.978118', 'Создана новая продажа. Автомобиль ID: 3, Клиент ID: 2');


--
-- TOC entry 4907 (class 0 OID 24948)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users (id, login, password, role_id) VALUES (2, 'man', '321', 2);
INSERT INTO public.users (id, login, password, role_id) VALUES (1, 'art', '123', 1);
INSERT INTO public.users (id, login, password, role_id) VALUES (4, 'adm', '456', 2);


--
-- TOC entry 4928 (class 0 OID 0)
-- Dependencies: 221
-- Name: cars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cars_id_seq', 35, true);


--
-- TOC entry 4929 (class 0 OID 0)
-- Dependencies: 219
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 10, true);


--
-- TOC entry 4930 (class 0 OID 0)
-- Dependencies: 215
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- TOC entry 4931 (class 0 OID 0)
-- Dependencies: 223
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_id_seq', 22, true);


--
-- TOC entry 4932 (class 0 OID 0)
-- Dependencies: 225
-- Name: sales_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_log_id_seq', 36, true);


--
-- TOC entry 4933 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- TOC entry 4749 (class 2606 OID 24977)
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (id);


--
-- TOC entry 4747 (class 2606 OID 24967)
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- TOC entry 4739 (class 2606 OID 24946)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- TOC entry 4741 (class 2606 OID 24944)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4753 (class 2606 OID 25005)
-- Name: sales_log sales_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_log
    ADD CONSTRAINT sales_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4751 (class 2606 OID 24985)
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- TOC entry 4743 (class 2606 OID 24955)
-- Name: users users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_key UNIQUE (login);


--
-- TOC entry 4745 (class 2606 OID 24953)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4757 (class 2620 OID 25020)
-- Name: sales before_sale_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER before_sale_insert BEFORE INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.check_car_not_sold();


--
-- TOC entry 4758 (class 2620 OID 25128)
-- Name: sales trg_sales_delete_log; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_sales_delete_log BEFORE DELETE ON public.sales FOR EACH ROW EXECUTE FUNCTION public.log_sale_delete();


--
-- TOC entry 4759 (class 2620 OID 25127)
-- Name: sales trg_sales_insert_log; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_sales_insert_log AFTER INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.log_sale_insert();


--
-- TOC entry 4760 (class 2620 OID 25114)
-- Name: sales trigger_update_car_status; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_car_status AFTER INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.sync_car_sold_status();


--
-- TOC entry 4755 (class 2606 OID 24986)
-- Name: sales sales_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(id) ON DELETE CASCADE;


--
-- TOC entry 4756 (class 2606 OID 24991)
-- Name: sales sales_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- TOC entry 4754 (class 2606 OID 24956)
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


-- Completed on 2025-12-26 22:48:16

--
-- PostgreSQL database dump complete
--

